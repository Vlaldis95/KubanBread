const sliderButtons = document.querySelectorAll('.slider__control');

// sliderButtons.forEach(button => {
//   button.remove();
//   button = null;
// })

// document.scripts['slider-default'].remove();

// document.scripts['slider'].remove();

